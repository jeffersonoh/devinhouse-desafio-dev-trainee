package br.com.devinhouse.thiago_mathias_simon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoDeAplicacaoDevinhouseThiagoMathiasSimonApplicationTests {

	@Test
	void contextLoads() {
	}

}
