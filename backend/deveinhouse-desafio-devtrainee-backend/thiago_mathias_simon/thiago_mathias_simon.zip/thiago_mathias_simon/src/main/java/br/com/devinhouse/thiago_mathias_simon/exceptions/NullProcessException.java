package br.com.devinhouse.thiago_mathias_simon.exceptions;

public class NullProcessException extends RuntimeException {

	private static final long serialVersionUID = 2670775835521741903L;

	public NullProcessException(String message) {
		super(message);
	}

}
