package br.com.devinhouse.thiago_mathias_simon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoDeAplicacaoDevinhouseThiagoMathiasSimonApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoDeAplicacaoDevinhouseThiagoMathiasSimonApplication.class, args);
	}

}
