package br.com.devinhouse.thiago_mathias_simon.repository;

import org.springframework.data.repository.CrudRepository;

import br.com.devinhouse.thiago_mathias_simon.entity.ProcessoEntity;

public interface ProcessoRepository extends CrudRepository<ProcessoEntity, Long> {
}